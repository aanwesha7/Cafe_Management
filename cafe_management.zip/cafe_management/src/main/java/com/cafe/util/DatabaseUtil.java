package com.cafe.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

public class DatabaseUtil {
    private static DataSource dataSource = null;
    private static final Properties properties = new Properties();
    
    static {
        try {
            // Load database properties
            try (InputStream input = DatabaseUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
                if (input == null) {
                    throw new RuntimeException("Unable to find db.properties");
                }
                properties.load(input);
            } catch (IOException e) {
                throw new RuntimeException("Error loading database properties", e);
            }
            
            // Initialize connection pool
            initConnectionPool();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize DatabaseUtil", e);
        }
    }

    private static void initConnectionPool() {
        try {
            // Using Apache DBCP for connection pooling
            Class.forName("org.apache.commons.dbcp2.BasicDataSource");
            
            // Create a new DataSource with connection pooling
            org.apache.commons.dbcp2.BasicDataSource ds = new org.apache.commons.dbcp2.BasicDataSource();
            ds.setDriverClassName(properties.getProperty("jdbc.driver"));
            ds.setUrl(properties.getProperty("jdbc.url"));
            ds.setUsername(properties.getProperty("jdbc.username"));
            ds.setPassword(properties.getProperty("jdbc.password"));
            
            // Connection pool configuration
            ds.setInitialSize(Integer.parseInt(properties.getProperty("jdbc.initialSize", "5")));
            ds.setMaxTotal(Integer.parseInt(properties.getProperty("jdbc.maxActive", "10")));
            ds.setMaxIdle(Integer.parseInt(properties.getProperty("jdbc.maxIdle", "5")));
            ds.setMinIdle(Integer.parseInt(properties.getProperty("jdbc.minIdle", "2")));
            ds.setMaxWaitMillis(Long.parseLong(properties.getProperty("jdbc.maxWait", "10000")));
            
            dataSource = ds;
            
        } catch (Exception e) {
            throw new RuntimeException("Error initializing connection pool", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        if (dataSource == null) {
            throw new SQLException("DataSource is not initialized");
        }
        return dataSource.getConnection();
    }
    
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
    public static void closeStatement(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing statement: " + e.getMessage());
            }
        }
    }
    
    public static void closeResultSet(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("Error closing result set: " + e.getMessage());
            }
        }
    }
    
    public static void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        closeResultSet(rs);
        closeStatement(stmt);
        closeConnection(conn);
    }
    
    public static void closeResources(Connection conn, Statement stmt) {
        closeStatement(stmt);
        closeConnection(conn);
    }
    
    public static void rollback(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                System.err.println("Error rolling back transaction: " + e.getMessage());
            }
        }
    }
}
