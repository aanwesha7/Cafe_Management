package com.cafe.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

public class DatabaseInitializer {
    private static final String INIT_SCRIPT = "/sql/create_tables.sql";
    
    public static void initializeDatabase() {
        try (InputStream inputStream = DatabaseInitializer.class.getResourceAsStream(INIT_SCRIPT)) {
            if (inputStream == null) {
                throw new RuntimeException("Database initialization script not found in classpath: " + INIT_SCRIPT + ". Make sure the SQL file is in the resources/sql/ directory.");
            }
            
            try (Connection conn = DatabaseUtil.getConnection();
                 Statement stmt = conn.createStatement()) {
                
                // Read the SQL script
                String sqlScript;
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                    sqlScript = reader.lines().collect(Collectors.joining("\n"));
                }
                
                // Split the script into individual statements
                String[] sqlStatements = sqlScript.split(";\\s*\n");
                
                // Execute each statement
                for (String sql : sqlStatements) {
                    if (!sql.trim().isEmpty()) {
                        try {
                            stmt.execute(sql);
                        } catch (SQLException e) {
                            System.err.println("Error executing SQL: " + sql);
                            System.err.println(e.getMessage());
                            // Continue with next statement
                        }
                    }
                }
                
                System.out.println("Database initialized successfully");
            }
            
        } catch (IOException | SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            throw new RuntimeException("Failed to initialize database", e);
        }
    }
    
    public static void main(String[] args) {
        System.out.println("Starting database initialization...");
        initializeDatabase();
        System.out.println("Database initialization completed.");
    }
}
