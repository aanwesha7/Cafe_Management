package com.cafe.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Utility class for password hashing and verification.
 * Uses Spring Security's BCrypt implementation.
 */
public class PasswordUtil {
    
    private static final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    
    /**
     * Hashes a raw password using BCrypt
     * @param rawPassword the raw password to hash
     * @return the hashed password
     */
    public static String hashPassword(String rawPassword) {
        return passwordEncoder.encode(rawPassword);
    }
    
    /**
     * Verifies a raw password against a hashed password
     * @param rawPassword the raw password to verify
     * @param hashedPassword the hashed password to compare against
     * @return true if the password matches, false otherwise
     */
    public static boolean verifyPassword(String rawPassword, String hashedPassword) {
        return passwordEncoder.matches(rawPassword, hashedPassword);
    }
    
    /**
     * Main method for testing password hashing
     */
    public static void main(String[] args) {
        // Example usage
        String password = "admin123";
        String hashed = hashPassword(password);
        System.out.println("Hashed password: " + hashed);
        
        // Verify the password
        boolean isMatch = verifyPassword(password, hashed);
        System.out.println("Password match: " + isMatch);
    }
}
