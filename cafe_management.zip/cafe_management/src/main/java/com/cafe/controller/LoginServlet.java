package com.cafe.controller;

import com.cafe.dao.UserDAO;
import com.cafe.model.User;
import com.cafe.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserDAO userDAO;
    
    @Override
    public void init() {
        userDAO = new UserDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Check if user is already logged in
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            // User is already logged in, redirect to dashboard
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        
        // Show login page
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String rememberMe = request.getParameter("rememberMe");
        
        try {
            // Authenticate user
            User user = userDAO.authenticate(username, password);
            
            if (user != null) {
                // Create session
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                
                // Set session timeout to 30 minutes
                session.setMaxInactiveInterval(30 * 60);
                
                // Set remember me cookie if requested
                if (rememberMe != null && rememberMe.equals("on")) {
                    Cookie rememberMeCookie = new Cookie("rememberUser", user.getUsername());
                    rememberMeCookie.setMaxAge(7 * 24 * 60 * 60); // 7 days
                    rememberMeCookie.setHttpOnly(true);
                    rememberMeCookie.setPath(request.getContextPath());
                    response.addCookie(rememberMeCookie);
                }
                
                // Update last login time
                userDAO.updateLastLogin(user.getUserId());
                
                // Redirect to dashboard based on user role
                response.sendRedirect(request.getContextPath() + "/dashboard");
                
            } else {
                // Authentication failed
                request.setAttribute("error", "Invalid username or password");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            throw new ServletException("Login failed", e);
        }
    }
}
