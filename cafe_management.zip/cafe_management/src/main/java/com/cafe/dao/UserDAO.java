package com.cafe.dao;

import com.cafe.model.User;
import com.cafe.util.DatabaseUtil;
import com.cafe.util.PasswordUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for User operations.
 */
public class UserDAO {
    
    private static final Logger logger = Logger.getLogger(UserDAO.class.getName());
    
    // SQL Queries
    private static final String INSERT_USER = 
        "INSERT INTO users (username, password, email, full_name, phone, role, is_active) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
    private static final String SELECT_USER_BY_ID = 
        "SELECT * FROM users WHERE user_id = ?";
        
    private static final String SELECT_USER_BY_USERNAME = 
        "SELECT * FROM users WHERE username = ?";
        
    private static final String SELECT_USER_BY_EMAIL = 
        "SELECT * FROM users WHERE email = ?";
        
    private static final String SELECT_ALL_USERS = 
        "SELECT * FROM users";
        
    private static final String UPDATE_USER = 
        "UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, role = ?, is_active = ? " +
        "WHERE user_id = ?";
        
    private static final String UPDATE_PASSWORD = 
        "UPDATE users SET password = ? WHERE user_id = ?";
        
    private static final String DELETE_USER = 
        "DELETE FROM users WHERE user_id = ?";
        
    private static final String UPDATE_LAST_LOGIN = 
        "UPDATE users SET last_login = ? WHERE user_id = ?";
    
    /**
     * Authenticate a user with username and password
     * @param username the username
     * @param password the plain text password
     * @return User object if authentication is successful, null otherwise
     */
    public User authenticate(String username, String password) {
        User user = findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
    
    /**
     * Create a new user
     * @param user the user to create
     * @return true if successful, false otherwise
     */
    public boolean createUser(User user) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(INSERT_USER, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, user.getUsername());
            // Store password directly without hashing
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getFullName());
            stmt.setString(5, user.getPhone());
            stmt.setString(6, user.getRole());
            stmt.setBoolean(7, user.isActive());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                return false;
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                }
            }
            
            return true;
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error creating user: " + user.getUsername(), e);
            return false;
        }
    }
    
    /**
     * Find a user by ID
     * @param userId the user ID to search for
     * @return User object if found, null otherwise
     */
    public User findById(int userId) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_USER_BY_ID)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToUser(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Find a user by username
     * @param username the username to search for
     * @return User object if found, null otherwise
     */
    public User findByUsername(String username) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_USER_BY_USERNAME)) {
            
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return mapResultSetToUser(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Find a user by email
     * @param email the email to search for
     * @return User object if found, null otherwise
     */
    public User findByEmail(String email) {
        String sql = SELECT_USER_BY_EMAIL;
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error finding user by email: " + email, e);
        }
        return null;
    }
    
    /**
     * Get all users
     * @return List of all users
     */
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_USERS)) {
            
            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    /**
     * Update a user's information (excluding password)
     * @param user the user with updated information
     * @return true if the update was successful, false otherwise
     */
    public boolean updateUser(User user) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(UPDATE_USER)) {
            
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getRole());
            stmt.setBoolean(6, user.isActive());
            stmt.setInt(7, user.getUserId());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Update a user's password
     * @param userId the ID of the user to update
     * @param newPassword the new plain text password
     * @return true if the update was successful, false otherwise
     */
    public boolean updatePassword(int userId, String newPassword) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(UPDATE_PASSWORD)) {
            
            String hashedPassword = PasswordUtil.hashPassword(newPassword);
            stmt.setString(1, hashedPassword);
            stmt.setInt(2, userId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Delete a user by ID
     * @param userId the ID of the user to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteUser(int userId) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(DELETE_USER)) {
            
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Updates the last login timestamp for a user
     * @param userId The ID of the user
     * @return true if the update was successful, false otherwise
     */
    public boolean updateLastLogin(int userId) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(UPDATE_LAST_LOGIN)) {
            
            // Check if last_login column exists before trying to update it
            try (Statement checkStmt = conn.createStatement();
                 ResultSet rs = checkStmt.executeQuery("SHOW COLUMNS FROM users LIKE 'last_login'")) {
                if (!rs.next()) {
                    // last_login column doesn't exist, so just return true
                    return true;
                }
            }
            
            // If we get here, the column exists, so update it
            stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(2, userId);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating last login for user ID: " + userId, e);
            return false;
        }
    }
    
    /**
     * Helper method to map a ResultSet to a User object
     */
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        user.setFullName(rs.getString("full_name"));
        user.setPhone(rs.getString("phone"));
        user.setRole(rs.getString("role"));
        user.setActive(rs.getBoolean("is_active"));
        user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        
        // Handle possible null updated_at
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) {
            user.setUpdatedAt(updatedAt.toLocalDateTime());
        }
        
        // Safely handle last_login column
        try {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            boolean hasLastLogin = false;
            
            // Check if last_login column exists
            for (int i = 1; i <= columnCount; i++) {
                if ("last_login".equalsIgnoreCase(metaData.getColumnName(i))) {
                    hasLastLogin = true;
                    break;
                }
            }
            
            if (hasLastLogin) {
                Timestamp lastLogin = rs.getTimestamp("last_login");
                if (!rs.wasNull()) {
                    user.setLastLogin(lastLogin.toLocalDateTime());
                }
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Error accessing last_login column", e);
        }
        
        return user;
    }
}
