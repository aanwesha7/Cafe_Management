package com.cafe.listener;

import com.cafe.util.DatabaseInitializer;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class AppContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Initializing Cafe Management System...");
        
        try {
            // Initialize the database
            DatabaseInitializer.initializeDatabase();
            System.out.println("Database initialization completed successfully");
            
            // You can add other initialization code here
            
        } catch (Exception e) {
            System.err.println("Error initializing application: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize application", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Shutting down Cafe Management System...");
        // Add cleanup code here if needed
    }
}
